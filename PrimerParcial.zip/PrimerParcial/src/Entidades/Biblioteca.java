package Entidades;

import Excepciones.RepeatedInstanceException;
import Interfaces.Leible;
import java.util.ArrayList;

public class Biblioteca {
    private ArrayList<Publicacion> publicaciones;

    public Biblioteca(){
        this.publicaciones = new ArrayList<Publicacion>();
    }

    public void agregarPublicacion(Publicacion p) throws RepeatedInstanceException{
        // contains usa equals asi que overrideo el mismo para las publicaciones mas adelante y comparo con el mismo
        // en caso de repetido tiro excepcion personalizada
        if(this.publicaciones.contains(p) && p != null){
            throw new RepeatedInstanceException("publicaciones");
        }
        this.publicaciones.add(p);
    }

    public String mostrarPublicaciones(){
        StringBuilder sb = new StringBuilder();
        for(Publicacion p : this.publicaciones){
            // acumula los toString uno debajo del otro
            sb.append(p.toString() + "\n");
        }
        return sb.toString();
    }
    
    public void leerPublicaciones(){
        // para cada publicacion si implementa Leible lo lee, si no avisa que no puede
        for(Publicacion p : this.publicaciones){
            if(p instanceof Leible){
                Leible pLeible = (Leible) p;
                pLeible.leer();
            }else{
                System.out.println(p.getTitulo() + " no es leible");
            }
        }
    }
}
