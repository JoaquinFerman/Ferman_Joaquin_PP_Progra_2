package Entidades;

public enum Generos {
    FICCION,
    NO_FICCION,
    CIENCIA,
    HISTORIA
}
