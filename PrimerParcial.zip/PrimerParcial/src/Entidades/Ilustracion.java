package Entidades;

import Excepciones.LessThanCeroException;

public class Ilustracion extends Publicacion{
    private String nombreIlustrador;
    private int ejeX;
    private int ejeY;

    public Ilustracion(String titulo, int fechaPublicacion, String nombreIlustrador, int ejeX, int ejeY) throws LessThanCeroException {
        super(titulo, fechaPublicacion);
        // los ejes no pueden ser menores a 1 (en este caso porque es int) > excepcion personalizada
        if(ejeX < 1){
            throw new LessThanCeroException("ejeX");
        }
        if(ejeY < 1){
            throw new LessThanCeroException("ejeY");
        }
        this.nombreIlustrador = nombreIlustrador;
        this.ejeX = ejeX;
        this.ejeY = ejeY;
    }

    // no se que clase vea primero pero esto para sobreescribir el metodo predeterminado de la clase proyect
    @Override
    public String toString(){
        return String.format("Ilustracion [ilustrador=%s, ancho=%d, alto=%d]", this.nombreIlustrador, this.ejeX, this.ejeY);
    }
}
