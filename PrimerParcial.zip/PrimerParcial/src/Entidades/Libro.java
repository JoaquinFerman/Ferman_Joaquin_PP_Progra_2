package Entidades;

import Interfaces.Leible;

public class Libro extends Publicacion implements Leible{
    private String autor;
    private Generos genero;
    
    public Libro(String titulo, int fechaPublicacion, String autor, Generos genero) {
        super(titulo, fechaPublicacion);
        this.autor = autor;
        this.genero = genero;
    }

    // informa lo que hace
    public void leer(){
        System.out.println("Leyendo: " + this.getTitulo());
    }

    @Override
    public String toString(){
        return String.format("Libro [autor=%s, genero=%s]", this.autor, this.genero.name());
    }
}
