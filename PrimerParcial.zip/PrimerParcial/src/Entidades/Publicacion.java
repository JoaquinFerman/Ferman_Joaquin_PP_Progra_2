package Entidades;

public abstract class Publicacion {
    private String titulo;
    private int fechaPublicacion;
    
    public Publicacion(String titulo, int fechaPublicacion) throws IllegalArgumentException {
        // la fecha no puede ser futura
        if(fechaPublicacion > 2024){
            throw new IllegalArgumentException("Esa fecha aun no ocurre");
        }
        this.titulo = titulo;
        this.fechaPublicacion = fechaPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    @Override
    public boolean equals(Object obj){
        // se considera que no es igual hasta que se demuestre lo contrario
        boolean retorno = false;

        // verifica si la clase es compatible
        if(obj != null && this.getClass() == obj.getClass()){
            Publicacion o = (Publicacion) obj;

            // atributos pedidos
            retorno = (this.fechaPublicacion == o.fechaPublicacion) && (this.titulo == o.titulo);
        }
        return retorno;
    }
}
