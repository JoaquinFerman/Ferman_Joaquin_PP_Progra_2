package Entidades;

import Excepciones.LessThanCeroException;
import Interfaces.Leible;

public class Revista extends Publicacion implements Leible{
    private int edicion;

    public Revista(String titulo, int fechaPublicacion, int edicion) throws LessThanCeroException{
        super(titulo, fechaPublicacion);
        // no puede ser una edicion menor a 1 por claras razones
        if(edicion < 1){
            throw new LessThanCeroException("Edicion");
        }
        this.edicion = edicion;
    }

    public void leer(){
        System.out.println("Leyendo: " + this.getTitulo());
    }

    @Override
    public String toString(){
        return String.format("Revista [numeroEdicion=%d]", this.edicion);
    }
}
