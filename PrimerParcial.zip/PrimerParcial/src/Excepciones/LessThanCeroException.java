package Excepciones;

public class LessThanCeroException extends Exception{
    public LessThanCeroException(String nombre){
        super(String.format("%S no puede tener un valor menor a 0"));
    }
}
