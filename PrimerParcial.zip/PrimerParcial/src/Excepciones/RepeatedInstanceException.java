package Excepciones;

public class RepeatedInstanceException extends Exception {
    public RepeatedInstanceException(String lista){
        super(String.format("La instancia ya se encuentra en %S", lista));
    }
}
