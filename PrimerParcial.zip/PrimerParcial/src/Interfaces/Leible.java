package Interfaces;

public interface Leible {
    // solo da la pauta de que sean leibles
    void leer();
}
