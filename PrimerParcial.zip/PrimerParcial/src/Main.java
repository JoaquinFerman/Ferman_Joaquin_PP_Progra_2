import java.util.InputMismatchException;
import java.util.Scanner;

import Entidades.Biblioteca;
import Entidades.Generos;
import Entidades.Ilustracion;
import Entidades.Libro;
import Entidades.Revista;
import Excepciones.LessThanCeroException;
import Excepciones.RepeatedInstanceException;

public class Main {
    public static void main(String[] args) {
        boolean salir = false;
        Biblioteca b1 = new Biblioteca();
        Libro l1 = new Libro("Historia de primaria", 2020, "Juan Gomez", Generos.HISTORIA);
        // si no lo declaro fuera del try, solo existiria dentro del mismo
        Revista r1 = null;
        Ilustracion i1 = null;

        try{
            r1 = new Revista("Revista Caras", 2024, 100);
        }catch (LessThanCeroException e){}
        try{
            i1 = new Ilustracion("Actividades para colorear", 2023, "Franco Colapinto", 20, 80);
        }catch (LessThanCeroException e){}
        try{
            b1.agregarPublicacion(l1);
            b1.agregarPublicacion(i1);
            b1.agregarPublicacion(r1);
        }catch (RepeatedInstanceException e){;}

        Scanner input = new Scanner(System.in);

        System.out.println("");
        while(!salir){
            System.out.print("""
(Ya existen una biblioteca y publicaciones predeterminadas)
Menu de pruebas:
1. Crear publicacion (y agregarla a la biblioteca)
2. Mostrar publicaciones
3. Leer publicaciones
4. Salir del programa

-> """);    
            int opcion;
            try{
                opcion = input.nextInt();
                input.nextLine();
            }catch (InputMismatchException e){
                opcion = 0;
            }
            
            switch (opcion) {
                case 1:
                    System.out.print("""
Crear:
1. Libro
2. Revista
3. Ilustracion

-> """);
                    int opcionSecundaria;
                    try{
                        opcionSecundaria = input.nextInt();
                        input.nextLine();
                    }catch (InputMismatchException e){
                        opcionSecundaria = 0;
                    }

                    switch (opcionSecundaria) {
                        case 1, 2, 3:
                            String titulo;
                            int fechaPublicacion;
                            System.out.print("Titulo: ");
                            titulo = input.nextLine().replace("\n", "");
                            System.out.print("Fecha de publicacion (Año): ");
                            try{
                                fechaPublicacion = input.nextInt();
                                input.nextLine();
                            }catch (InputMismatchException e){
                                break;
                            }
                            

                            switch (opcionSecundaria) {
                                case 1:
                                String autor;
                                Generos genero = null;
                                System.out.print("Autor: ");
                                autor = input.nextLine().replace("\n", "");
                                System.out.print("Genero (ficcion, no_ficcion, ciencia, historia): ");
                                String generoTemp = input.nextLine().replace("\n", "").toLowerCase();

                                switch (generoTemp) {
                                    case "ficcion":
                                    genero = Generos.FICCION;
                                    break;
                                    case "no_ficcion":
                                    genero = Generos.NO_FICCION;
                                    break;
                                    case "ciencia":
                                    genero = Generos.CIENCIA;
                                    break;
                                    case "historia":
                                    genero = Generos.HISTORIA;
                                    break;
                                    default:
                                    System.out.println("Genero no disponible");
                                    break;
                                }
                                if(genero != null){
                                    try{
                                        b1.agregarPublicacion(new Libro(titulo, fechaPublicacion, autor, genero));
                                    }catch (RepeatedInstanceException e) {;}
                                }
                                case 2:
                                    System.out.println("No llegue (no se creo nada)");
                                    break;
                                case 3:
                                    System.out.println("No llegue (no se creo nada)");
                                    break;
                            
                            default:
                            break;
                        }
                    }
                    break;
            
                case 2:
                    System.out.println(b1.mostrarPublicaciones());
                    break;

                case 3:
                    b1.leerPublicaciones();
                    break;
                
                case 4:
                    salir = true;
                    break;
                
                default:
                    System.out.println("Opcion no valida");
                    break;
            }
        System.out.println("Enter para continuar...");
        input.nextLine();
        }

        input.close();
    }
}
